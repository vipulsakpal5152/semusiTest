class OrderHandler {
    constructor ({ log_id, controller }) {
        this.log_id = log_id
        this.controller = controller
    }

    async createOrder (inputs, user_id) {
        console.log('REQUEST headers data handler=> ', user_id);

        try {
            return {
                status: 200,
                ...(await this.controller.createOrder(inputs, user_id))
            }
        } catch (err) {
            console.log(err);
            return {status: 400, message: err.message}
        }
    }

    async getOrders (user_id) {
        try {
            return {
                status: 200,
                ...(await this.controller.getOrders(user_id))
            }
        } catch (err) {
            console.log(err);
            return {status: 400, message: err.message}
        }
    }

    async getOrderReport () {
        try {
            return {
                status: 200,
                ...(await this.controller.getOrderReport())
            }
        } catch (err) {
            console.log(err);
            return {status: 400, message: err.message}
        }
    }
}

module.exports = OrderHandler