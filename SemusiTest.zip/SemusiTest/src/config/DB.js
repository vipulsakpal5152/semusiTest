const PostgreSQLInstance = {
    users: {
        data: [
            {
                id: 1,
                name: 'VIPUL',
                email: 'vipulsakpal51@gmail.com',
            },
            {
                id: 2,
                name: 'Dummy',
                email: 'Dummy@gmail.com',
            }
        ]
    },
    orders: {
        data: [
            {
                "id": "PROD_12",
                "user_id": "1",
                "product_id": "PROD_12",
                "quantity": 2,
                "total_order_value": 1440000,
                "created_at": "2024-12-11T08:06:18.394Z"
            },
            {
                "id": "PROD_123",
                "user_id": "1",
                "product_id": "PROD_123",
                "quantity": 4,
                "total_order_value": 440000,
                "created_at": "2024-12-11T08:06:18.394Z"
            }
        ]
    }
}

const MongoDBInstance = {
    products: {
        data: [
            {
                "_id": "PROD_12345",
                "name": "PROD SAM0",
                "price": 720000
            },
            {
                "_id": "PROD_12345",
                "name": "PROD SAM1",
                "price": 550000
            }
        ]
    }
}

module.exports = {
    PostgreSQLInstance,
    MongoDBInstance
}