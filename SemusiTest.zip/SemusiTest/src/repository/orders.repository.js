class OrderRepository {
    constructor ({ log_id, doa }) {
        this.log_id = log_id
        this.doa = doa
    }

    async createOrder (inputs, user_id) {
        return await this.doa.createOrder(inputs, user_id)
    }

    async getOrders (user_id) {
        return await this.doa.getOrders(user_id)
    }
    
    async getOrderReport () {
        return await this.doa.getOrderReport()
    }
}

module.exports = OrderRepository