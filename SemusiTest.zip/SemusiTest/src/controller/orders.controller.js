class OrderController {
    constructor ({ log_id, repository }) {
        this.log_id = log_id
        this.repository = repository
    }

    async createOrder (inputs, user_id) {
            return this.repository.createOrder(inputs, user_id)
    }

    async getOrders (user_id) {
            return this.repository.getOrders(user_id)
    }

    async getOrderReport () {
            return this.repository.getOrderReport()
    }
}

module.exports = OrderController