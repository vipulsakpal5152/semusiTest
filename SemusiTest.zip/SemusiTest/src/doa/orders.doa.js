class OrderDoa {
    constructor ({ log_id, PostgreSQLInstance, MongoDBInstance }) {
        this.log_id = log_id
        this.PostgreSQLInstance = PostgreSQLInstance
        this.MongoDBInstance = MongoDBInstance
    }

    async createOrder (inputs, user_id) {
        // console.log('CHECK ==>', this.PostgreSQLInstance.users.data, user_id);
        // console.log('CHECK ==>', this.PostgreSQLInstance.users.data.filter(val => val.id == user_id));        
        if (this.PostgreSQLInstance.users.data.filter(val => val.id == user_id).length === 0 ){
            throw new Error('USER Not Found')
        }

        const res = {
            "message": "Order created successfully",
            "order_id": "UUID"
        }
        for (const element of inputs) {
            // console.log('element =>', element)
            const MongoOrderData = this.MongoDBInstance.products.data.filter(val => val._id == element.product_id)
            if (MongoOrderData.length === 0 ){
                throw new Error('PRODUCT Not Found')
            }
            this.PostgreSQLInstance.orders.data.push({
                id: element.product_id,
                user_id: user_id,
                product_id: element.product_id,
                quantity: element.total_sales,
                total_order_value: MongoOrderData[0].price * element.total_sales,
                created_at: new Date()
            })
            res.order_id = element.product_id
            res.data = this.PostgreSQLInstance.orders.data
            console.log('PODUCT INSERTED....');
            
        }
        return res
    }

    async getOrders (user_id) { 
        console.log('GETUSER => ',this.PostgreSQLInstance.users.data, user_id);
        
        if (this.PostgreSQLInstance.users.data.filter(val => val.id == user_id).length === 0 ){
            throw new Error('USER Not Found')
        }

        const data = this.PostgreSQLInstance.orders.data.filter(val => val.user_id == user_id)

        return { data }
    }

    async getOrderReport () { 
        return { data: this.PostgreSQLInstance.orders.data }
    }
}

module.exports = OrderDoa