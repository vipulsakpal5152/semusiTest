const express = require('express')
const ordersRoute = require('./routers/orders')
const usersRoute = require('./routers/users')
// console.log('ordersRoute=>', ordersRoute);

// console.log(express);
const app = express()
// app.use(express.json())

app.use('/', ordersRoute)
app.use('/users', usersRoute)

app.listen(3000, () => {
    console.log('Server Listing on port 3000');
})