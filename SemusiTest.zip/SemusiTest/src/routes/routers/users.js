const express = require('express')
// console.log(express);
const OrderHandler = require('../../handler/orders.handler')
const OrderController = require('../../controller/orders.controller')
const OrderRepository = require('../../repository/orders.repository')
const OrderDoa = require('../../doa/orders.doa')
const DB = require('../../config/DB')
console.log('CHEKING =>', DB);

const log_id = 123456
const instance = new OrderHandler({
    log_id,
    controller: new OrderController({
        log_id,
        repository: new OrderRepository({
            log_id,
            doa: new OrderDoa({
                log_id,
                PostgreSQLInstance: DB.PostgreSQLInstance,
                MongoDBInstance: DB.MongoDBInstance
            })
        })
    })
})

const router = express.Router()
// router.use(express.json())
router.use((req, res, next) => {
    next()
})

router.get('/:id/orders', async (req, res) => {
    console.log('REQUEST params id=> ', req.params.id);
    res.send(await instance.getOrders(req.params.id))
    // res.send('OKAy')
})

module.exports = router