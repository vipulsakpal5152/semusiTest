const express = require('express')
// console.log(express);
const OrderHandler = require('../../handler/orders.handler')
const OrderController = require('../../controller/orders.controller')
const OrderRepository = require('../../repository/orders.repository')
const OrderDoa = require('../../doa/orders.doa')
const DB = require('../../config/DB')
console.log(DB);

const log_id = 123456
const instance = new OrderHandler({
    log_id,
    controller: new OrderController({
        log_id,
        repository: new OrderRepository({
            log_id,
            doa: new OrderDoa({
                log_id,
                PostgreSQLInstance: DB.PostgreSQLInstance,
                MongoDBInstance: DB.MongoDBInstance
            })
        })
    })
})

const router = express.Router()
router.use(express.json())
router.use((req, res, next) => {
    console.log('REQUEST DATA => ', req.body);
    console.log('REQUEST headers => ', req.headers.user_id);
    next()
})

router.post('/orders', async (req, res) => {
    console.log('REQUEST headers data post=> ', req.headers.user_id);
    res.send(await instance.createOrder(req.body, req.headers.user_id))
    // console.log(req)
    
    // res.send('OKAY')
})

router.get('/orders/report/sales', async (req, res) => {
    res.send(await instance.getOrderReport())
    // console.log(req)
    
    // res.send('OKAY')
})

module.exports = router